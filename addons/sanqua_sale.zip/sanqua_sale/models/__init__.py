from . import sale_order
from . import stock_inventory_report
from . import res_partner
from . import sanqua_division
